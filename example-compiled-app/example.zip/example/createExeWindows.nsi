;Function .onInit в этой функции будут параметры, которые вам необходимо менять для вашего приложения
;Поддержка юникода
Unicode True 
;Подключение макросов для облегченя работы, подробнее можно узнать найдя эти файлы и проситав описание
!include x64.nsh 
!include "MUI2.nsh"
!include NTProfiles.nsh
;Название инсталлятора.
Name "Starter" 
; Файл для записи. Это имя будет иметь наш инсталлятор
Outfile "StarterInstaller.exe"
;Отображения хода установки программы 
ShowInstDetails show
;Запуск приложения от имени администратора
RequestExecutionLevel admin
;Глобальные переменные
Var JAR_FILE
Var JRE_x64
Var JRE_x32
Var DESCTOPLINK
Var UNINSTLINK
Var ERROR_MESSAGE
Var JRE_FOLDER
Var WORK_DIR
;Иконка установщика
!define MUI_ICON "icon.ico"
;Функции из MUI2.nsh которые могут выполнить ряд действий после установки 
!define MUI_FINISHPAGE_RUN
!define MUI_FINISHPAGE_RUN_CHECKED
!define MUI_FINISHPAGE_RUN_FUNCTION runApp
;Набор макросов 
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_LANGUAGE English
!insertmacro MUI_LANGUAGE Russian



;Функция которая будет вызвана перед основным блоком. В этой функции мы присвоим значения выше объявленным переменным и определим директорию для установки по умолчанию
Function .onInit
;добавить переменную на java
 SectionSetSize "" 300000 
;Указываем название распакованного jre каталога 
 StrCpy $JRE_FOLDER "jre-21.0.8-windows-x64"
;Указываем сообщение в случае ошибки загрузки
 StrCpy $ERROR_MESSAGE "Coudn't download file , write please us to https://vk.com/cem_game"
;Указываем название иконки запуска
 StrCpy $DESCTOPLINK "Starter.lnk"
;Указываем название иконки удаления
 StrCpy $UNINSTLINK "StarterUninstall.lnk"
;Указываем расположение пускателя. 
 StrCpy $JAR_FILE "https://github.com/gdevby/starter-app/raw/java_21/example-compiled-app/starter-core-1.25.jar"
;Указываем расположение zip архива для 64 разрядной операционной системы
 StrCpy $JRE_x64 "https://github.com/gdevby/starter-app/raw/java_21/example-compiled-app/jre_for_installer/jre-21.0.8-windows-x64.7z" 
;Указываем расположение zip архива для 32 разрядной операционной системы
 StrCpy $JRE_x32 "https://github.com/gdevby/starter-app/raw/java_21/example-compiled-app/jre_for_installer/jre-8u281-windows-i586.7z" 
;Исходя из разрядности операционной системы определяем директорию для установки по умолчанию
	${if} ${RunningX64}
 	 StrCpy $InstDir "$ProgramFiles64\StarterInstaller"
	${Else}
  	StrCpy $InstDir "$ProgramFiles\StarterInstaller"
	${EndIf}
FunctionEnd

;Главный логический блок или секция
Section 
;Установка директории загрузки
 SetOutPath "$INSTDIR"
 DetailPrint "install directory is $INSTDIR"
;Вызов метода на удаление старых файлов которые были до этого установлены, при желании можно удалить вызов этого метода.
Call removeApp
;Создаем недостающие пути для нашего приложения
 CreateDirectory $INSTDIR
;Устанавливаем иконку
File icon.ico
;Логический оператор if else для проверки разрядности операционной системы
${if} ${RunningX64}
;Используем плагин Inetc для того чтобы загрузить файлы по urn jar файл и jre для запуска jar файла. Так же обрабатываем возникшие ошибки
	inetc::get /caption "downloading files" /popup "" "$JRE_x64" "$INSTDIR\zip_jre.7z" "$JAR_FILE" "$INSTDIR\starter-core.jar" /END
	Pop $0
	DetailPrint "downloaded code is $0" 
	StrCmp $0 "OK" +3
		MessageBox MB_OK "$ERROR_MESSAGE"
		Return
${Else}
	inetc::get /caption "downloading files" /popup "" "$JRE_x32" "$INSTDIR\zip_jre.7z" "jar_file" "$INSTDIR\starter-core.jar" /END
	Pop $0
	DetailPrint "downloaded code is $0" 
	StrCmp $0 "OK" +3
		MessageBox MB_OK "$ERROR_MESSAGE"
		Return
${EndIf}
  ;отображение распоковки архива
	DetailPrint "unzip"
  ;Распаковка архива при помощи плагина Nsis7z
	Nsis7z::Extract "$INSTDIR\zip_jre.7z"
  ;Удаляем загруженный архив т.к он распокаван больше не нужен
	Delete "$INSTDIR\zip_jre.7z" 
  ;Определение пути куда будет установлено приложение
  !define NTProfilePaths::IgnoreLocal
  ${EnumProfilePaths} EnumMyProfiles
	;Создание uninstall.exe для удаления приложения
	#uninstall
	SetOutPath $INSTDIR
	WriteUninstaller "$INSTDIR\uninstall.exe"
	CreateShortcut "$SMPROGRAMS\$DESCTOPLINK" "$INSTDIR\uninstall.exe"
SectionEnd


;Секция для удаления файлов программы
Section "uninstall"
	Delete "$desktop\$DESCTOPLINK"
	Delete "$SMPROGRAMS\$UNINSTLINK"
	Delete "$INSTDIR\starter-core.jar"
	Delete "$INSTDIR\autostart.file.flag.txt"	
	Delete "$INSTDIR\uninstall.exe"	
	Delete "$INSTDIR\icon.ico"
	Delete "$INSTDIR"	
	RMDir /r "$INSTDIR"
SectionEnd


;Функия для запуска приложения после установки
Function runApp
  StrCpy $0 '"$INSTDIR\$JRE_FOLDER\bin\javaw.exe" -jar "$INSTDIR\starter-core.jar"'
  SetOutPath "$WORK_DIR"
  Exec $0
FunctionEnd
;Функия которую мы вызываем перед началом установки
Function removeApp
	RMDir /r "$INSTDIR\$JRE_FOLDER"
	Delete "$desktop\$DESCTOPLINK"
	Delete "$SMPROGRAMS\$UNINSTLINK"
	Delete "$INSTDIR\starter-core.jar"	
	Delete "$INSTDIR\uninstall.exe"	
	Delete "$INSTDIR\icon.ico"	
	Delete "$APPDATA\Microsoft\Windows\Start Menu\Programs\Startup\$DESCTOPLINK"
FunctionEnd


Function EnumMyProfiles 
        Pop $0
        SetOutPath "$0\AppData\Roaming\" 
        StrCpy $WORK_DIR "$0\AppData\Roaming"
        SetShellVarContext all 
        CreateShortcut "$desktop\$DESCTOPLINK" "$INSTDIR\$JRE_FOLDER\bin\javaw.exe" '-jar "$INSTDIR\starter-core.jar"' "$INSTDIR\icon.ico" 0
        Push ""
FunctionEnd